   <footer class="page-footer   black z-depth-3" >
    <div class="footer-copyright">
      <div class="container">
      © copyright 2015 Made by <a class="green-text text-lighten-5" href="#"> Batch 3</a> 
      </div>
    </div>
  </footer>
   <script src="js/jquery-2.1.1.min.js"></script>
 <script src="js/materialize.min.js"></script>

 <script src="js/index.js"></script>